<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
    <title></title>

	<script type="text/javascript">
      var site_url = "http://tugas-ahir.ervan/Server_Travenote/";
	  function timeSince(date) {

			var seconds = Math.floor((new Date() - date) / 1000);

			var interval = Math.floor(seconds / 31536000);

			if (interval > 1) {
				return interval + " years";
			}
			interval = Math.floor(seconds / 2592000);
			if (interval > 1) {
				return interval + " months";
			}
			interval = Math.floor(seconds / 86400);
			if (interval > 1) {
				return interval + " days";
			}
			interval = Math.floor(seconds / 3600);
			if (interval > 1) {
				return interval + " hours";
			}
			interval = Math.floor(seconds / 60);
			if (interval > 1) {
				return interval + " minutes";
			}
			return Math.floor(seconds) + " seconds";
		}
		
		function hhha(){
			var x = timeSince(new Date("Fri Feb 12 2011 13:05:16 GMT+0700 (SE Asia Standard Time)"));
			console.log(x);
		}
    </script>
  </head>
  <body>
  <div style="width: 50% !important; height: 50% !important">
	<img src="assets/img/2_IMG_20160217_193449.jpg" width="100%" height="100%">
  </div>
	<button onclick="hhha()">Test</button>
	<?php 
		date_default_timezone_set("Asia/Jakarta");
		$expire_time = 'Fri Feb 12 2016 13:29:52 GMT+0700 (SE Asia Standard Time)';
		$expire_time = substr($expire_time, 0, strpos($expire_time, '('));

		echo "Created date is " . date("Y-m-d h:i:sa", strtotime($expire_time));
	?>
  </body>
</html>
