<?php

class Location{
	
	private $latitude = null;
	private $longitude = null;
	private $time_there = null;
	private $note = null;
	
	public function __construct(){}
	
	public function getLatitude(){		
		return $this->latitude;
	}
	
	public function setLatitude($lat){
		$this->latitude = $lat;
	}
	
	public function getLongitude(){		
		return $this->longitude;
	}
	
	public function setLongitude($lng){
		$this->longitude = $lng;
	}
	
	public function getTimeThere(){		
		return $this->time_there;
	}
	
	public function setTimeThere($time){
		$this->time_there = $time;
	}
	
	public function getNote(){		
		return $this->note;
	}
	
	public function setNote($note){
		$this->note = $note;
	}
	
}

?>