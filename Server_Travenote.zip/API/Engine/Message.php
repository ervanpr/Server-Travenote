<?php

class Message{
	
	public static $MESSAGE_ERROR = 0;
	public static $MESSAGE_SUCCESS = 1;
	
	private $message;
	
	public function __construct(){}
	
	public function setMessage($message, $message_type = null){
		if($message_type == null){
			$this->message = $message;
		}
		else{
			
			switch ($message_type) {
				case Message::$MESSAGE_ERROR:
					
					$this->message = array('message' => $message, 'code' => Message::$MESSAGE_ERROR);
					break;
				
				case Message::$MESSAGE_SUCCESS:
					
					$this->message = array('message' => $message, 'code' => Message::$MESSAGE_SUCCESS);
					break;
			}
			
		}
		
	}
	
	public function getMessage(){
		 return $this->message;
	}
	
}

?>