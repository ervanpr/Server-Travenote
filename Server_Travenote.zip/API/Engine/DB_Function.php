<?php
/*
 * This file contain database function like query and etc.
 */

class DB_Function{
	
	private $db;
	
	public function __construct(){		
		require_once 'Engine/DB_Connection.php';
		$this->db = new DB_Connection();
		$this->db->connect();		
	}
	
	public function storeLocation(Location $location){
		require_once 'Engine/Message.php';
		$message;
		$message_code;
		$msg_obj = new Message();
		
		if($location->getLatitude() != null AND $location->getLongitude() != null){
			$result = mysql_query("INSERT INTO location_service (latitude, longitude, waktu) VALUES (
			'".$location->getLatitude()."', '".$location->getLongitude()."', '".$location->getTimeThere()."')")
			or die(mysql_error());
			
			if($result){				
				$message = "Success Stored";
				$message_code = Message::$MESSAGE_SUCCESS;
			}
			else{
				$message = "Failed Stored";
				$message_code = Message::$MESSAGE_ERROR;
			}
			
		}
		else{
			$message = "Total Error";
			$message_code = Message::$MESSAGE_ERROR;
		}		
		
		$msg_obj->setMessage($message, $message_code);
		
		return $msg_obj;
		
	}
	
}
 


?>