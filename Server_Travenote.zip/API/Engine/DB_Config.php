<?php 
/*
 * This file contain Database configuration for use to connect to database
 */

 define("DB_HOST", "mysql.idhostinger.com");//change to spicify your database link
 define("DB_USER", "u217705284_ervan");//change to spicify your database username
 define("DB_PASSWORD", "Dhepixtetepboj0ku");//change to spicify your database password
 define("DB_NAME", "u217705284_gmaps");//change to spicify your database name

?>