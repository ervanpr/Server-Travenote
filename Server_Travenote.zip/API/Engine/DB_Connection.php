<?php
/*
 * This file contain about database connection (non-query module)
 */
 
 class DB_Connection{
 	
	public function __construct(){
		
	}
	
	public function __destruct(){
		
	}
	
	public function connect(){
		require_once 'Engine/DB_Config.php';
		
		$connect = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD) or die(mysql_error());
		
		mysql_select_db(DB_NAME, $connect) or die(mysql_error());
		
		return $connect;
	}
	
	public function close(){
		mysql_close();
	}
	
 }

?>