<?php

	/*
	 * This file contains about JSON helper for easier usage
	 */
	 
	 class JSONService{
	 	
		public static $JSON_HEADER = 'Content-Type: application/json';
	 	
		public function __construct(){
			
		}
		
		public function setToJSON($array){
			header(JSONService::$JSON_HEADER);
			echo json_encode($array);
		}
		
		
		
	 }

?>