<?php
	date_default_timezone_set("Asia/Jakarta");
	require_once 'Engine/DB_Function.php';
	$db = new DB_Function();

	$post = json_decode(file_get_contents("php://input"), true);
	
	if((!empty($post['lat']) AND !empty($post['lng']))){		
		require_once 'App/Location.php';
		require_once 'Engine/JSONService.php';
		$date = getdate(date("U"));
		$wkt = "$date[mday]/$date[mon]/$date[year]::$date[hours]:$date[minutes]:$date[seconds]";
		$location = new Location;
		$location->setLatitude($post['lat']);
		$location->setLongitude($post['lng']);
		$location->setTimeThere($wkt);
		$x = $db->storeLocation($location);
		
		$json = new JSONService();
		$json->setToJSON($x->getMessage());
	}else{
		echo json_encode(array("test"=>"Nge-test yaa !!!"));
	}
	
	?>