/*var io = angular.module('starter', ['ionic']);

io.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) { 
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
});*/


'use strict';

var app = angular.module('TraveNote', ['ionic', 'ngCordova']);

app.service('MainService', function($q, $timeout){
  this.user = {
      name: "",
      id:  "",
      avatar: "",
      get: {}
    }
    
  this.mapData = {};

  this.getPlaceImage = {};
  
  this.dateService  = {

    getInterval : function (date) {

      var seconds = Math.floor((new Date() - date) / 1000);

      var interval = Math.floor(seconds / 31536000);

      if (interval > 1) {
        return interval + " Years";
      }
      interval = Math.floor(seconds / 2592000);
      if (interval > 1) {
        return interval + " Months";
      }
      interval = Math.floor(seconds / 86400);
      if (interval > 1) {
        return interval + " Days";
      }
      interval = Math.floor(seconds / 3600);
      if (interval > 1) {
        return interval + " Hours";
      }
      interval = Math.floor(seconds / 60);
      if (interval > 1) {
        return interval + " Minutes";
      }
      return Math.floor(seconds) + " seconds";
    },

    getDay: function(d){      
      switch(d.getDay()){
        case 0:
          return 'Sunday';
        case 1:
          return 'Monday';
        case 2:
          return 'Tuesday';
        case 3:
          return 'Wednesday';
        case 4:
          return 'Thursday';
        case 5:
          return 'Friday';
        case 6:
          return 'Saturday';        
      }
    },
    
    getMonth: function(d){
      var n;
      switch(d.getMonth()){
        case 0:
          n = "January";
        break;
        case 1:
          n = "February";
        break;
        case 2:
          n = "March";
        break;
        case 3:
          n = "April";
        break;
        case 4:
          n = "May";
        break;
        case 5:
          n = "June";
        break;
        case 6:
          n = "July";
        break;
        case 7:
          n = "August";
        break;
        case 8:
          n = "September";
        break;
        case 9:
          n = "October";
        break;
        case 10:
          n = "November";
        break;
        case 11:
          n = "December";
        break;
        default:
          n = "Unknown";
        break;
      }
      
      return n;
    }
  }
    
  this.sendPlaceComment = function(id, e, loading, elem, elem_input){   
    loading.show();
    var d = new Date();
    var ms = this;
    $.ajax({
      url: site_url+'index.php/gmaps/insertPlaceComment',
      type: 'post',
      dataType: 'json',
      data: {id_user: this.user.id, txtComment: e, id_place: id, tgl:d, wkt: d, author: this.user.name},
      success: function(data){        
        var prep = "<a class=\"item item-avatar\"><img src=\"http://www.travenote.com/api/assets/img/"+ms.user.avatar+"\"><h2>"+ms.user.name+"</h2><small style=\"font-size: 9px; color: #c0c0c0;\">Posted on: Just Now</small><p>"+e+"</p></a>";
        if(data.stat == 1){
          $("#"+elem).append(prep);
          $("#"+elem_input).val("");
        }
        loading.hide();
      },
      error: function(){
        loading.hide();
        alert('Failed when sending comment');
      }
    });
  }
  
  this.sendPostComment = function(id, e, loading, elem, elem_input){    
    loading.show();
    var d = new Date();
    var ms = this;
    $.ajax({
      url: site_url+'index.php/gmaps/insertPostComment',
      type: 'post',
      dataType: 'json',
      data: {id_user: this.user.id, txtComment: e, id_postingan: id, tgl:d, wkt: d, author: this.user.name},
      success: function(data){ 
      console.log(data);       
        var prep = "<a class=\"item item-avatar\"><img src=\"http://www.travenote.com/api/assets/img/"+ms.user.avatar+"\"><h2>"+ms.user.name+"</h2><small style=\"font-size: 9px; color: #c0c0c0;\">Posted on: Just Now</small><p>"+e+"</p></a>";
        if(data.stat == 1){
          $("#"+elem).append(prep);
          $("#"+elem_input).val("");
        }
        loading.hide();
      },
      error: function(){
        loading.hide();
        alert('Failed when sending comment');
      }
    });
  }
//ini service untuk search

  this.md = [];

  var jampes = this.md;

  this.md = this.md.sort(function(a, b) {
  
    var mdA = a.name.toLowerCase();
    var mdB = b.name.toLowerCase();
  
    if(mdA > mdB) return 1;
    if(mdA < mdB) return -1;
    return 0;
  });

    this.searchAirlines = function(searchFilter) {
        console.log(jampes);
        console.log('Searching airlines for ' + searchFilter);

        var deferred = $q.defer();

      var matches = md.filter( function(airline) {
        if(md.name.toLowerCase().indexOf(searchFilter.toLowerCase()) !== -1 ) return true;
      })

        $timeout( function(){
        
           deferred.resolve( matches );

        }, 100);

        return deferred.promise;

    };

});

app.factory('SearchingDataService', function($q, $timeout, MainService) {

  var md = [MainService.mapData];

  md = md.sort(function(a, b) {
  
    var mdA = a.name.toLowerCase();
    var mdB = b.name.toLowerCase();
  
    if(mdA > mdB) return 1;
    if(mdA < mdB) return -1;
    return 0;
  });

    var searchAirlines = function(searchFilter) {
        console.log(md);
        console.log('Searching airlines for ' + searchFilter);

        var deferred = $q.defer();

      var matches = md.filter( function(airline) {
        if(md.name.toLowerCase().indexOf(searchFilter.toLowerCase()) !== -1 ) return true;
      })

        $timeout( function(){
        
           deferred.resolve( matches );

        }, 100);

        return deferred.promise;

    };

    return {

        searchAirlines : searchAirlines

    }
});

app.controller("Ctrl_Home", function($scope, $ionicModal, $location, MainService, $ionicLoading, $window, $http, $ionicActionSheet, $cordovaSocialSharing){

  $scope.userUtil = MainService;
  $scope.site_url = site_url;
  $scope.img_path = $scope.site_url+"assets/img/";
  $scope.share_url= site_url+"index.php/shared/detail/"

  $scope.$on('modal_post_comment.hidden', function() {
    $("#list_post_comment_activity").empty();
    console.log("List post koment hidden");
  });

  $scope.$on('modal_comment.hidden', function() {
    $("#list_comment").empty();
    console.log("List post koment hidden");
  });

  $scope.$on('modal_post_comment.removed', function() {
    $("#list_post_comment_activity").empty();
    console.log("List post koment hidden");
  });

  $scope.$on('modal_comment.removed', function() {
    $("#list_comment").empty();
    console.log("List post koment hidden");
  });
  
  $scope.ffff = function(){
    if(MainService.user.name == "" || MainService.user.id == ""){
      //$window.location.href = site_url+"dev/#/login";
      $location.path('/login');
    }
    else{
    $scope.showLoading();
    var d, i;
    $scope.activity_user = {
      post: [],
      post_on: []
    }
      $.ajax({
        url: site_url+'index.php/gmaps/getUserActivity',
        type: 'post',
        dataType: 'json',
        data: {id_user: MainService.user.get.id_user},
        success: function(data){
          $scope.activity_user.post = data;         
          for(i=0;i<$scope.activity_user.post.length; i++){
            d = new Date($scope.activity_user.post[i].date);
            $scope.activity_user.post_on[i] = "About "+MainService.dateService.getInterval(d)+" ago";
          }
          console.log($scope.activity_user);
          $scope.hideLoading();
        },
        error: function(err){
          console.log(err);
          $scope.hideLoading();
          alert(JSON.stringify(err));
        }
      });
    } 
  }

  $scope.getCommentPlace = function (id){
    $.ajax({
      url: site_url+'index.php/gmaps/getPlaceComments',
      type: 'post',
      dataType: 'json',
      data: {id: id},
      success: function(comments){
        $scope.post_on = [];
        var i;
        var d;
        $scope.place_comments = comments;       
      },
      error: function(){
        alert('Unknown Error.!!!');
      }
    });
  }
  
  $scope.mainLoading = {
    show: function() {
      $ionicLoading.show({
        template: 'Loading...'
      });
    },
    hide: function(){
      $ionicLoading.hide();
    }
  }

  $scope.showLoading = function() {
    $ionicLoading.show({
      template: 'Loading...'
    });
  };
  $scope.hideLoading = function(){
    $ionicLoading.hide();
  };

  $scope.home_tab = function(){
    angular.element("[element-type = header-tab].active").removeClass("active");
    angular.element("[data-view = home]").addClass("active");
  }

  $scope.location_tab = function(){
    (angular.element("[element-type = header-tab].active")).removeClass("active");
    angular.element("[data-view = location]").addClass("active");
  }

  $scope.setting_tab = function(){
    (angular.element("[element-type = header-tab].active")).removeClass("active");
    angular.element("[data-view = setting]").addClass("active");
  }
//for detail
  $ionicModal.fromTemplateUrl('modal.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(modal) {
    $scope.modal = modal;
  });

  $scope.openModal = function() {
  alert('xx');
    //$scope.modal.show();
  };
  $scope.closeModal = function() {
    $scope.modal.hide();
  };
  //Cleanup the modal when we're done with it!
  
  //for comments modal
  $ionicModal.fromTemplateUrl('modal-comment.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(x) {
    $scope.modal_comment = x;
  });

  $scope.openModalComment = function(id) {
  $scope.getCommentPlace(id);
    $scope.modal_comment.show();
  };
  $scope.closeModal = function() {
    $scope.modal_comment.hide();
  };  
  
  $ionicModal.fromTemplateUrl('modal-post-comment.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(x) {
    $scope.modal_post_comment = x;
  });
  
  $scope.openModalPostComment = function(){
    $scope.modal_post_comment.show();
  }
  
  $scope.closeModalPostComment = function(){
    $scope.modal_post_comment.hide();
  }
  
  $scope.getAllPostComments = function(id){
    $scope.tmp_post_id = id;
    $scope.post_comments = {
      content: [],
      on: []
    }
    $scope.mainLoading.show();

    var config = {
      url: site_url+"index.php/gmaps/getAllPostComments",
      data: {id: $scope.tmp_post_id},  
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },  
    }

    var comment = $http(config);
    comment.success(function(data){
      var d, i;
      $scope.post_comments.content = data;
      for(i=0;i<$scope.post_comments.content.length; i++){
        d = new Date($scope.post_comments.content[i].date);
        $scope.post_comments.on[i] = MainService.dateService.getInterval(d)+" ago";
      }
      $scope.mainLoading.hide();
      $scope.openModalPostComment();
    });

    comment.error(function(){
      $scope.mainLoading.hide();
      alert("Failed to load data..!!!");
    });
  }

   $ionicModal.fromTemplateUrl('modal-detail-post.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(x) {
    $scope.modal_place_detail_post = x;
  });
  
  $scope.openModalPlaceDetailPost = function(){
    console.log(window);
    $scope.modal_place_detail_post.show();
  }
  
  $scope.closeModalPlaceDetailPost = function(){
    $scope.modal_place_detail_post.hide();
  }

  $scope.showModalDetailPostLocation = function(id){
    $scope.showLoading();
    $.ajax({
      url: site_url+"index.php/gmaps/getplacedetail",
      type: 'post',
      dataType: 'json',
      data: {pry: id},
      success: function(data){
        $scope.hideLoading();
        $scope.modal_place_detail_post.data_detail = data.data_place;
        var d = new Date($scope.modal_place_detail_post.data_detail.date);
        $scope.modal_place_detail_post.data_detail.post_on = MainService.dateService.getInterval(d)+" ago";
        $scope.modal_place_detail_post.data_detail.image_data = data.img_data;
        console.log($scope.modal_place_detail_post.data_detail);        
        $scope.openModalPlaceDetailPost();
      },
      error: function(){
        $scope.hideLoading();
        alert("Failed: Unknown Error");
      }
    });
  }

  $scope.countPostLike = function(e, val){       
    e.x.like_count = parseInt(e.x.like_count) + val;
  }

  $scope.likePostActivity = function(t, e, id, isRepeat){
    var l = $(e.currentTarget).children();

    if(l.hasClass("dark")){         
      l.removeClass("dark");
      l.addClass("calm");

      var config = {
        url: site_url+"index.php/gmaps/setlike",
        data: {id: id, like: "1"},  
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },  
      }

      var like = $http(config);
      like.success(function(data){
        console.log(data);
        if(data.stat == 1){
          t.x.like_count = parseInt(t.x.like_count) + 1;
          l.removeClass("calm");
          l.addClass("positive");
        }
        else{
          l.removeClass("calm");
          l.addClass("dark");
        }
      });
      like.error(function(data){
        l.removeClass("calm");
        l.addClass("dark");
      });
    }
    else{
      l.removeClass("positive");
      l.addClass("calm");
      var config = {
        url: site_url+"index.php/gmaps/setlike",
        data: {id: id, like: "-1"},  
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },  
      }

      var like = $http(config);
      like.success(function(data){
        console.log(data);
        if(data.stat == 1){ 
          t.x.like_count = parseInt(t.x.like_count) - 1;
          l.removeClass("calm");
          l.addClass("dark");
        }
        else{
          l.removeClass("calm");
          l.addClass("positive");
        }
      });
      like.error(function(data){
        l.removeClass("calm");
        l.addClass("positive");
      });
    }
  }

  $scope.createShareUrl = function(id, lat, lng){
    return $scope.share_url+id+"/"+lat+"/"+lng;
  }

  $scope.shareLocationButton = function(t, d, id, lat, lng, img){   
     $cordovaSocialSharing
      .share(t, d, img, $scope.createShareUrl(id, lat, lng)) // Share via native share sheet
      .then(function(result) {
        //alert(JSON.stringify(result));
      }, function(err) {
        alert("Unknown Error..!!!");
     });
  }
  
  //Cleanup the modal when we're done with it!
  $scope.$on('$destroy', function() {
    $scope.modal_comment.remove();
    $scope.modal.remove();
    $scope.modal_post_comment.remove();
  });  

});

app.controller("MapController", function($scope, $q, $location, $cordovaFileTransfer, $ionicLoading, $ionicModal, $cordovaCamera, $ionicPopup, $timeout, $window, MainService, $http, $ionicHistory, $cordovaSocialSharing){
  $scope.location = {};
  $scope.place = {};
  $scope.comments;
  $scope.ms = MainService;  
  $scope.share_url= site_url+"index.php/shared/detail/";
  
  $scope.jj = function(){
    alert('bla bla bla');
  }
  
  $scope.ffff = function(){
    if(MainService.user.name.length < 1 || MainService.user.id.length < 1){
      //$window.location.href = site_url+"dev/#/login";
      $location.path('/login');
    }   
  }
  
  $scope.createShareUrl = function(id, lat, lng){
    return $scope.share_url+id+"/"+lat+"/"+lng;
  }

  $scope.shareMapLocationButton = function(t, d, id, lat, lng, img){    
     $cordovaSocialSharing
      .share(t, d, img, $scope.createShareUrl(id, lat, lng)) // Share via native share sheet
      .then(function(result) {
        //alert(JSON.stringify(result));
      }, function(err) {
        alert("Unknown Error..!!!");
     });
  }  
  
  $scope.showLoading = function() {
    $ionicLoading.show({
      template: 'Loading...'
    });
  };
  $scope.hideLoading = function(){
    $ionicLoading.hide();
  };
  
  
  $ionicModal.fromTemplateUrl('modal.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function(modal) {
      $scope.modal = modal;
    });
    
    $scope.openModal = function() {
      $scope.modal.show();
    };
    $scope.closeModal = function() {
      $scope.modal.hide();
    };
    
    //Cleanup the modal when we're done with it!
    
    $scope.$on('$destroy', function() {
      $scope.modal.remove();
    });
    
    $ionicModal.fromTemplateUrl('modal-detail.html', {
    scope: $scope,
      animation: 'slide-in-up'
    }).then(function(modaladdnew) {
      $scope.modalAddLocation = modaladdnew;
    });
    
    $scope.openModalAddLocation = function() {
        $scope.showLoading();
        /*alert(JSON.stringify($scope.place));
        var x = $.post("https://maps.googleapis.com/maps/api/geocode/json?latlng="+$scope.place.lat+","+$scope.place.lng+"&key=AIzaSyDQHu8c3CTgvmcdsG_5AvF0jYGWv7E_Mw0");
      
      x.done(function(data){
        $scope.hideLoading();
        alert(JSON.stringify(data));
      });*/
      
      var config = {
          url: "https://maps.googleapis.com/maps/api/geocode/json?latlng="+$scope.place.lat+","+$scope.place.lng+"&key=AIzaSyDQHu8c3CTgvmcdsG_5AvF0jYGWv7E_Mw0",
          method: "POST"
        }
  
        var GL = $http(config);
        GL.success(function(data){          
           var i;
            if(parseInt(data.results[1].address_components[2].long_name) == null){
                i = 1;
            }else{
                i = 0;
            }
        
          var kec_long = data.results[i].address_components[2].long_name;
            var kec_short = data.results[i].address_components[2].short_name;
          var kab_long = data.results[i].address_components[3].long_name;
            var kab_short = data.results[i].address_components[3].short_name;
            $scope.place.address = kec_short+" ("+kab_short+") "+i;
            
        $scope.place.tgl = new Date();
            $scope.hideLoading();
            //alert(JSON.stringify(data));
            $scope.modalAddLocation.show();
        });
  
        GL.error(function(data){
        $scope.hideLoading();
          alert(JSON.stringify(data));
        });
    }
    
    $scope.closeModalAddLocation = function() {
      $scope.modalAddLocation.hide();
    };
    //Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
      $scope.modalAddLocation.remove();
    });
    
    $scope.saveNewLocation = function(){
            
      $scope.place.id_user = MainService.user.get.id_user;
      $scope.showLoading();
      var d = new Date();
      var dn = d.getDate()+"-"+d.getMonth()+1+"-"+d.getFullYear();
      var tn = d.getHours()+"-"+d.getMinutes()+"-"+d.getSeconds();
      var opt = {
      fileKey: "image_place",
      fileName: MainService.user.get.id_user+"_"+dn+"-"+tn+"-"+$scope.imgSrc.substr($scope.imgSrc.lastIndexOf('/') + 1),
      mimeType: "image/jpeg",
      params: {data: $scope.place}
    };
    
    var xurl = site_url+"index.php/gmaps/saveNewPlace";
    
    $cordovaFileTransfer.upload(xurl, $scope.imgSrc, opt).then(
      function(result){
        $scope.hideLoading();
        alert(JSON.stringify(result.response));
      },
      function(err){
        $scope.hideLoading();
          alert(JSON.stringify(err));
      },
      function(progress){
        //alert();
      }
    );
    }
    
    var takePictureOpt = { 
            quality : 100, 
            destinationType : Camera.DestinationType.FILE_URI,
            sourceType : Camera.PictureSourceType.CAMERA, 
            allowEdit : !true,
            encodingType: Camera.EncodingType.JPEG,
          targetWidth: 800,
          targetHeight: 480,
            saveToPhotoAlbum: function(){
              var r = false;
              if(MainService.user.get === "YES"){
                r = true;
              }             
              return r;
            }
        };
   
   $scope.takePicture = function() {
      $cordovaCamera.getPicture(takePictureOpt).then(function(imageData) {
          $scope.imgSrc;
          $scope.imgSrc = imageData;
          $scope.openModalAddLocation();
      }, function(err) {
          console.log(err);
      });
  }
  
    $scope.showLocationExistConfirm = function(name,id_place) {
     var confirmPopup = $ionicPopup.confirm({
       title: 'Lokasi Sudah ada...!',
       template: 'Dengan nama \"'+name+'\", Apakah anda di sini ?'
     });
     confirmPopup.then(function(res) {
       if(res) {
        $scope.isHere = true;
        $scope.showModalDetailLocation(id_place);
       } 
       else {
          $scope.takePicture();        
       }
     });
   };
   
  $scope.showModalDetailLocation = function(id){
    $scope.location = {};
    $scope.showLoading();
    $.ajax({
      url: site_url+"index.php/gmaps/getplacedetail",
      type: 'post',
      dataType: 'json',
      data: {pry: id},
      success: function(data){
        $scope.hideLoading();
        console.log(data);
        var d;
        var i;
        $scope.post_on = [];
        $scope.location = data.data_place;
        $scope.maps_comments = data.report_place;
        for(i=0;i<$scope.maps_comments.length; i++){
          d = new Date($scope.maps_comments[i].date);
          $scope.post_on[i] = MainService.dateService.getInterval(d)+" ago";
        }
        
        var detaildate = new Date($scope.location.date);
        $scope.location.post_on = MainService.dateService.getInterval(detaildate)+" ago";
        $scope.location.image_data = data.img_data;
        
        console.log($scope.post_on);
        console.log($scope.maps_comments);
        console.log($scope.location);
        alert(JSON.stringify($scope.location.image_data));
        $scope.openModal();
      },
      error: function(){
        $scope.hideLoading();
        alert("Failed: Unknown Error");
      }
    });
  }
  


  $scope.map;
  $scope.result = {};
  $scope.markers = [];
  $scope.directionDisplay;
  $scope.directionService = new google.maps.DirectionsService();
  
  $scope.cameraAdd = function(){

  }
  
  $scope.isPlaceExist = function(){
  $scope.showLoading();
    if(navigator.geolocation) {
      $scope.place = {};
        navigator.geolocation.getCurrentPosition(function(position) {
      
        $scope.place.lat = position.coords.latitude;
        $scope.place.lng = position.coords.longitude;
      
        $.ajax({
          url: site_url+"index.php/gmaps/isPlaceExists",
          dataType: 'json',
          type: 'post',
          data: {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          },
          success: function(data){
          console.log(data);
            if(data.sts == '1'){        
              $scope.showLocationExistConfirm(data.data.name, data.data.id_place);
            }
            else{
              $scope.takePicture();
            }     
          },
          error: function(data){
            $scope.hideLoading();
            alert(JSON.stringify(data));
          },
          complete: function(){
            $scope.hideLoading();
          }
        });
      });
    }else{
      $scope.hideLoading();
      alert("Error: Tidak dapat mendeteksi lokasi");
    }
  }

      $scope.initialize = function() { 
        $scope.directionDisplay = new google.maps.DirectionsRenderer();
        
          var mapOptions = {
            zoom: 15
          };
          $scope.map = new google.maps.Map(document.getElementById('map-canvas'),
              mapOptions);          
              
              //execute method that first running on load event          
              $scope.showMarkerPlace();
              $scope.getCurrentPos();
            
        $scope.directionDisplay.setMap($scope.map);
      }
    
      $scope.getCurrentPos = function(){
          // Try HTML5 geolocation
          if(navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) { 
              var pos = new google.maps.LatLng(parseFloat(position.coords.latitude),
                                               parseFloat(position.coords.longitude));

              new google.maps.InfoWindow({
                map: $scope.map,
                position: pos,
                content: 'Anda...'
              });

              $scope.map.setCenter(pos);
              
            }, function() {
              $scope.handleNoGeolocation(true);
            });
          } else {
            // Browser doesn't support Geolocation
            $scope.handleNoGeolocation(false);
          }
      }

      $scope.showMarkerPlace = function(){
        $scope.dataAllLocation = {};
          $.ajax({
              url: site_url+'index.php/gmaps/getAllLocation',
              dataType: 'json',
              cache: false,
              success: function(data){
                  $scope.dataAllLocation = {};
                  $scope.md = data;
                  console.log($scope.md);

                  $scope.md = $scope.md.sort(function(a, b) {
    
                    var mdA = a.name.toLowerCase();
                    var mdB = b.name.toLowerCase();
                  
                    if(mdA > mdB) return 1;
                    if(mdA < mdB) return -1;
                    return 0;
                  });

                  $scope.dataAllLocation = data;
                  $.each($scope.dataAllLocation, function(index, value){
                      var pos = new google.maps.LatLng(parseFloat(data[index].lat), parseFloat(data[index].lng));
                      $scope.placeMarker(pos, data[index].id_place);                            
                  });
                  
              }
          });
        }

      $scope.handleNoGeolocation = function(errorFlag) {
        if (errorFlag) {
          var content = 'Error: The Geolocation service failed.';
        } else {
          var content = 'Error: Your browser doesn\'t support geolocation.';
        }

        var options = {
          map: $scope.map,
          position: new google.maps.LatLng(60, 105),
          content: content
        };

        var infowindow = new google.maps.InfoWindow(options);
        $scope.map.setCenter(options.position);
      }

      $scope.addPlace = function(){
          $("#loading_block").show();
          if(navigator.geolocation) {
              navigator.geolocation.getCurrentPosition(function(position) {
                var pos = new google.maps.LatLng(position.coords.latitude,
                                                 position.coords.longitude);

                var infowindow = new google.maps.InfoWindow({
                  map: $scope.map,
                  position: pos,
                  content: 'Ini lokasi anda sekarang'
                });
                map.setCenter(pos);

              $.post('https://maps.googleapis.com/maps/api/geocode/json?latlng='+position.coords.latitude+','+position.coords.longitude+'&key=AIzaSyDQHu8c3CTgvmcdsG_5AvF0jYGWv7E_Mw0')
                  .done(function(data){
            console.log(data);
                      var i;
                          if(parseInt(data.results[1].address_components[2].long_name) == null){
                              i = 1;
                          }else{
                              i = 0;
                          }                   
                      
                      var kec_long = data.results[i].address_components[2].long_name;
                      var kec_short = data.results[i].address_components[2].short_name;
                      var kab_long = data.results[i].address_components[3].long_name;
                      var kab_short = data.results[i].address_components[3].short_name;
                      $("#address").val(kec_short+" ("+kab_short+") "+i);
                  });

                $("#addPlaceModal").modal('show');
                $("#addPlaceModal").on('shown.bs.modal', function(){
                  $("#latitude").val(position.coords.latitude);
                  $("#longitude").val(position.coords.longitude);
                  $("#loading_block").hide();
                });

              }, function() {
                handleNoGeolocation(true);
              });
            } else {
              // Browser doesn't support Geolocation
              handleNoGeolocation(false);
              $("#loading_block").show();
            }
      }

      $scope.placeMarker = function(pos, id_place) {
        var image_icon = [

          site_url+'assets/img/Biru.png',
          site_url+'assets/img/Hitam.png',
          site_url+'assets/img/Kuning.png'

        ];

        var icon = new google.maps.MarkerImage(
          image_icon[Math.floor(Math.random() * image_icon.length)],
          null,
          null,
          null,//new google.maps.Point(40, 110), 
          new google.maps.Size(30.77, 44.46)
        ); 
        
              var marker = new google.maps.Marker({
                  position: pos,
                  map: $scope.map,
                  icon: icon
              });
              
              marker.addListener('click', function(){
                  $scope.showModalDetailLocation(id_place)
              });
              
              $scope.markers.push(marker);
      }

    $scope.drawRoute = function(latDestination, lngDestination, TMode){
      if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(function(position) { 
          var start = new google.maps.LatLng(parseFloat(position.coords.latitude), parseFloat(position.coords.longitude));                         
          var destination = new google.maps.LatLng(parseFloat(latDestination), parseFloat(lngDestination));
          
          var draw_route = {
            origin: start,
            destination: destination,
            travelMode: google.maps.TravelMode[TMode]
          }
        
          $scope.directionService.route(draw_route, function(response, status) {
            if (status == google.maps.DirectionsStatus.OK) {
              $scope.directionDisplay.setDirections(response);
              //console.log(response );
            }
            else{
              //console.log(start);
              //console.log(destination);            
              alert("Mode yang anda pilih tidak di dukung di rute ini, kami memberikan rute dengan mode DRIVING");
              var draw_route_default = {
                origin: start,
                destination: destination,
                travelMode: google.maps.TravelMode.DRIVING
              }
              $scope.directionService.route(draw_route_default, function(response, status){
                $scope.directionDisplay.setDirections(response);
              });
            }
          });     
        
        }, function(){
          $scope.handleNoGeolocation(true);
        });
      }
            
      
    }
    
    $scope.searchPage = function(){
      $location.path("/searchPage");
    }

    $scope.removeRoute = function(){
      $scope.directionDisplay.set('directions', null);
    }

    $scope.$on('$ionicView.loaded', function(){
      $scope.initialize();
    });
    
    $scope.$on("$destroy", function(){
      $ionicHistory.clearCache();
    });

      /*google.maps.event.addDomListener(window, 'load', function(){
          //$scope.initialize();
          console.log("xxxxxxxxx");
      });*/
//ini untuk search

    //$scope.md = [];    

    /*$scope.md = $scope.md.sort(function(a, b) {
    
      var mdA = a.name.toLowerCase();
      var mdB = b.name.toLowerCase();
    
      if(mdA > mdB) return 1;
      if(mdA < mdB) return -1;
      return 0;
    });*/

      $scope.searchAirlines = function(searchFilter) {
          console.log($scope.md);
          console.log('Searching airlines for ' + searchFilter);

          var deferred = $q.defer();

        var matches = $scope.md.filter( function(airline) {
          if($scope.md.name.toLowerCase().indexOf(searchFilter.toLowerCase()) !== -1 ) return true;
        })

          $timeout( function(){
          
             deferred.resolve( matches );

          }, 100);

          return deferred.promise;

      };

    $scope.dataSearchLocName = { "airlines" : [], "search" : '' };

    $scope.searchLocName = function() {

      $scope.searchAirlines($scope.dataSearchLocName.search).then(
        function(matches) {
          $scope.dataSearchLocName.airlines = matches;
        }
      )
    }


});

app.controller('LoginCtrl', function($scope, $window, MainService, $location, $ionicLoading, $http){
  $scope.logosrc = site_url+"assets/img/logo.png";
  
  $scope.loginLoading = {
    show: function() {
      $ionicLoading.show({
        template: 'Login...'
      });
    },
    hide: function(){
      $ionicLoading.hide();
    }
  }
  
  $scope.doLogin = function(mail,  pass){
    
    if(mail.length <= 1 || pass.length <= 1){
      alert("Email and Password Not Correct..!!!");
    }
    else{
      $scope.loginLoading.show();
      var config = {
        url: site_url+"index.php/gmaps/loginUser",
        data: {email: mail, password: pass},  
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }  
      }
  
      var comment = $http(config);
      comment.success(function(data){     
        $scope.loginLoading.hide();
        if(data.loged_in === 1){
        MainService.user.name = data.nama;
            MainService.user.id = data.id_user;
            MainService.user.avatar = data.avatar;
            MainService.user.get = data;
        $location.path('/home');
        }
        else{
          alert(JSON.stringify(data));
        }       
      });
  
      comment.error(function(data){
        $scope.loginLoading.hide();
        alert("Login Failed, Check your Internet Connection...!!!");
      });
    }   
  }
});

app.controller('SettingCtrl', function($scope, MainService, $http, $ionicLoading, $location){
  $scope.settingLoading = {
    show: function() {
      $ionicLoading.show({
        template: 'Saving...'
      });
    },
    hide: function(){
      $ionicLoading.hide();
    }
  }

  $scope.user = MainService.user.get;
  $scope.$on("$ionicView.beforeEnter", function(){
    $scope.isDirty = false;
    $scope.setting.Nama = $scope.user.nama;
  $scope.setting.Pass = $scope.user.password;
  $scope.setting.Email = $scope.user.email;
  $scope.setting.Alamat = $scope.user.alamat;
  $scope.setting.Save = $scope.user.save_picture;
  });
  
  $scope.setting = {};
  
  $scope.setting.Nama = $scope.user.nama;
  $scope.setting.Pass = $scope.user.password;
  $scope.setting.Email = $scope.user.email;
  $scope.setting.Alamat = $scope.user.alamat;
  $scope.setting.Save = $scope.user.save_picture;  
  
  $scope.formSettingChanged = function(){
    $scope.isDirty = true;
  }
  
  $scope.saveSetting = function(){
  $scope.settingLoading.show();
    var configs = {
      url: site_url+"index.php/gmaps/updateSetting",
      data: { data: $scope.setting, id: MainService.user.id },  
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }  
    }  
    
    var settings = $http(configs);
    settings.success(function(data){
      $scope.settingLoading.hide();
      if(data.stat === 1){
      MainService.user.name = data.data.nama;
          MainService.user.id = data.data.id_user;
          MainService.user.avatar = data.data.avatar;
          MainService.user.get = data.data;
      }
      else{
        alert(JSON.stringify(data));
      }
    });
    settings.error(function(data){
     $scope.settingLoading.hide();
     alert(JSON.stringify(data));
    });
  }
  
  $scope.logoutFromApp = function(){
    MainService.user.name = "";
    MainService.user.id = "";
    MainService.user.avatar = "";
    MainService.user.get = {};
    $scope.settingLoading.show();
    setTimeout(function(){
      $scope.settingLoading.hide();
      $location.path("/login");
    }, 5000);   
  }
});

app.controller('RegisterCtrl', function($scope, $location, MainService, $http, $ionicLoading){
  $scope.register = {};
  
  $scope.registerLoading = {
    show: function() {
      $ionicLoading.show({
        template: 'Register...'
      });
    },
    hide: function(){
      $ionicLoading.hide();
    }
  }
  
  $scope.doRegister = function(a,b,c,d,e){
    
  }
  
  $scope.doRegisterFix = function(){      
    var config = {
      url: site_url+"index.php/gmaps/registerUser",
      data: $scope.register,  
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }  
    }    
    
    $scope.registerLoading.show();
    
    var reg = $http(config);
    reg.success(function(data){
      $scope.registerLoading.hide();
      if(data.status === 1){
        alert("Register Successfull");
        $location.path("/login");
      }
      else{
        alert("Register Failed");
      }
    });
    
    reg.error(function(data){
      $scope.registerLoading.hide();
      alert(JSON.stringify(data));
    });
    
  }
  
  
});

app.controller("SearchCtrl", function($scope, MainService){
  $scope.dataSearchLocName = { "airlines" : [], "search" : '' };

    $scope.searchLocName = function() {

      MainService.searchAirlines($scope.data.search).then(
        function(matches) {
          $scope.data.airlines = matches;
        }
      )
    }
});

app.config(function($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise('/')

  $stateProvider.state('home', {
    url: '/home',
    templateUrl: 'home.html',
    controller: 'Ctrl_Home',
    cache: false
  }).
  state('location', {
    cache: false,
    url: '/location',
    templateUrl: 'location.html',
    controller: 'MapController'
  }).
  state('setting', {
    cache: false,
    url: '/setting',
    templateUrl: 'setting.html',
    controller: 'SettingCtrl'
  }).
  state('login', {
    cache: false,
    url: '/login',
    templateUrl: 'login.html',
    controller: 'LoginCtrl'
  }).
  state('register', {
    cache: false,
    url: '/register',
    templateUrl: 'register.html',
    controller: 'RegisterCtrl'
  }).
  state('searchPage', {
    cache: false,
    url: '/searchPage',
    templateUrl: 'search.html',
    controller: 'MapController'
  }).
  state('loginFirst', {
    cache: false,
    url: '/',
    templateUrl: 'login.html',
    controller: 'LoginCtrl'
  });
});