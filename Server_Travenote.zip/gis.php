<?php
mysql_select_db('tugas_jancok',mysql_connect('localhost', 'root', ''));
/*Rumus Haversine
 * 3959 Untuk Jarak dalam Miles
 * 6371 Untuk Jarak dalam Kilometer 
 */
 
 $lat = -7.601715;
 $lng = 110.425886;

$haversine = "6371 * acos( cos( radians($lat) ) * cos( radians(m.y) ) * cos( radians($lng) - radians(m.x) ) + sin( radians($lat) ) * sin( radians(m.y) ) )";
        
        $str = "SELECT nama_atm, y AS lat, x AS lng, ".$haversine." AS distance FROM atm AS m HAVING distance < 1 ORDER BY distance";
		
$query = mysql_query($str) or die(mysql_error());
$i = 1;
//$s = mysql_fetch_assoc($query) or die(mysql_error());
//print_r($s);
echo "<table border='1'>";
while($x = mysql_fetch_assoc($query)or die(mysql_error())){
	echo "<tr>";
	echo "<td>$i</td>";
	echo "<td>$x[nama_atm]</td>";
	echo "<td>$x[lat]</td>";
	echo "<td>$x[lng]</td>";
	echo "<td>".round($x['distance'], 2)."</td>";
	echo "</tr>";
	$i++;
}
echo "</table>";
?>