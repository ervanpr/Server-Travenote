<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo domain_url(); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo cssPath(); ?>bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo cssPath(); ?>bootflat.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo cssPath(); ?>font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo cssPath(); ?>style.css">
    <link href='http://fonts.googleapis.com/css?family=Raleway:700,400' rel='stylesheet' type='text/css'>
    <style>
        
    </style>
</head>

<body>
    
    <nav class="navbar navbar-default"> 
        <div class="container-fluid">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Gmaps</a>
          </div>

          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
              <li class="active"><a href="#">Link <span class="sr-only">(current)</span></a></li>
              <li><a id="addPlace" href="#">Add Place</a></li>
              <li><a id="removeRoute" onclick="removeRoute();" href="#">Add Place</a></li>
            </ul>
            <form class="navbar-form navbar-left" role="search">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Search">
              </div>
              <button type="submit" class="btn btn-default">Submit</button>
            </form>
            <ul class="nav navbar-nav navbar-right">
                <li><a id="testLink" href="#">Link</a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Action</a></li>
                  <li><a href="#">Another action</a></li>
                  <li><a href="#">Something else here</a></li>
                  <li class="divider"></li>
                  <li><a href="#">Separated link</a></li>
                </ul>
              </li>
            </ul>
          </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
      </nav>
    <!--ALERT-->
    <center>
    <div id="submit_place_fail" class="alert alert-custom alert-danger" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong>Failed to save this place, cek your connection</strong>
    </div>    
    <div id="submit_place_exist" class="alert alert-custom alert-info alert-dismissable" role="alert">
        <button type="button" class="close" id="close_exist" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong>Sepertinya tempat ini sudah ada dengan nama:</strong>
    </div>
    <div id="submit_place_success" class="alert alert-custom alert-success alert-dismissable" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong>Success</strong>
    </div>
    </center>
    
    
    
    <!--Canvas Map-->
    <div id="map-canvas"></div>    
    <div id="loading_block"></div>
    <!--Addons for UI & UX-->
    <!-- Modal -->
    <div class="modal fade" id="addPlaceModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Add Place</h4>
          </div>
          <div class="modal-body">
              <form id="place_id">
                  <div class="form-group">
                      <input placeholder="Place Name" name="name" id="name" class="form-control" type="text">
                  </div>
                  <div class="form-group">
                      <input placeholder="Category" name="category" id="category" class="form-control" type="text">
                  </div>
                  <div class="form-group">
                      <input name="address" id="address" class="form-control" type="text" readonly>
                  </div>
                  <div class="form-group">
                      <textarea class="form-control" name="message" id="message" placeholder="About this place..."></textarea>
                  </div>
                  <input class="form-control" name="latitude" id="latitude" type="hidden">
                  <input class="form-control" name="longitude" id="longitude" type="hidden">
              </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="save_place" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Cencel</button>
          </div>
        </div>
      </div>
    </div><!--end-modal-->
    
    <!-- Place detail view -->
	<div class="modal fade" id="detail_place_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
		<center><img id="loading_ajax_detail" src="<?php echo imgPath() ?>ajax-loading.gif"></center>
			<div class="modal-content"  id="place_detail">				
			</div>
		</div>
	</div>
    
	<script type="text/javascript">
		var site_url = "<?php echo domain_url(); ?>";
	</script>
    <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDQHu8c3CTgvmcdsG_5AvF0jYGWv7E_Mw0"></script>
    
    <script type="text/javascript" src="<?php echo jsPath(); ?>jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="<?php echo jsPath(); ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo jsPath(); ?>maps.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#addPlace").on('click', function(){
                addPlace();
            });
            
            $("#place_id").submit(function(e){
                var data = $(this).serializeArray();
                $.ajax({
                    url: "<?php echo sitePath() ?>gmaps/insertplace",
                    data: data,
                    type: "POST",
                    dataType: 'json',
                    success: function(data, textStatus, jqXHR){
                        //console.log(data.data[0].id);
                        var stts = (parseInt(data.status));
                        if(stts === 1){
                            $("#submit_place_success").fadeIn();
                            setTimeout(function(){
                                $("#submit_place_success").fadeOut();
                            }, 1500);
							var myLatlng = new google.maps.LatLng($("#latitude").val(), $("#longitude").val());
							placeMarker(myLatlng);
                        }
                        else if(stts === 2){
                            console.log(data);
                            $.ajax({
                                url: "<?php echo sitePath() ?>gmaps/getNearestPlace",
                                data: {id: data.data[0].id_place},
                                type: "POST",
                                dataType: 'json',
                                success: function(data){
                                    $("#submit_place_exist").append("\
                                        <div>\n\
                                            <p><strong>"+data[0].name+"</strong></p>\n\
                                            <button class='btn btn-success'>Ini</button> atau <button class='btn btn-warning'>Ini</button>\n\
                                        </div>\n\
                                    ");
                                    $("#submit_place_exist").fadeIn();
                                }
                            });                                                         
                        }
                        else{
                            $("#submit_place_fail").show();
                            setTimeout(function(){
                                $("#submit_place_fail").hide();
                            }, 1500);                           
                        }
                    },
                    error: function(data){
                        $("#submit_place_fail").show();
                        setTimeout(function(){
                            $("#submit_place_fail").hide();
                        }, 1500);
                    }
                }).done(function(data){
                    $("#addPlaceModal").modal('hide');
                    console.log(data.status);
                });
                e.preventDefault();
            });
            
            $("#save_place").on('click', function(){
                $("#place_id").submit();
            });
            
            $('#testLink').click(function(){
                $.post('http://maps.googleapis.com/maps/api/geocode/json?latlng=-8.0085849,110.3098374&sensor=false')
                    .done(function(data){
                        console.log(data);
                    });
            });
            
            $("#close_exist").on('click', function(){
                $("#submit_place_exist").fadeOut();
                $('#submit_place_exist').find('div:last-child').remove();
            });
			
			//button send comment
        });
    </script>
</body>
</html>