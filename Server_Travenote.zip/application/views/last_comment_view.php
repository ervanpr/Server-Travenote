<div style="background-color: #ccc; margin-bottom: 5px;" class="row">
	<div style="margin-left: 0px !important; margin-bottom: 5px; margin-top: 5px;" class="col-xs-10 col-sm-10 col-md-10">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12">                                
				<div class="col-xs-1 col-sm-1 col-md-1">
					<img style="float: left;" width="30" height="30" class="img-circle" src="<?php echo imgPath() ?>user.png">
				</div>
				<div style="margin-top: -10px;" class="col-xs-8 col-sm-8 col-md-11">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12">
							<h6 style="border-bottom: 1px dashed #f0f0f0;"><?php echo $name; ?></h6>
							<p style="margin-top: -10px;"><?php echo $comment; ?></p>
						</div>
					</div>                                    
				</div>
			</div>
		</div>
	</div>
</div>