<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo domain_url(); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo cssPath(); ?>bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo cssPath(); ?>bootflat.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo cssPath(); ?>font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo cssPath(); ?>style.css">
    <link href='http://fonts.googleapis.com/css?family=Raleway:700,400' rel='stylesheet' type='text/css'>
    <style>
        
    </style>
</head>

<body>
    <pre>
		<?php 
			print_r($detail);
		?>
	</pre>
	<script type="text/javascript">
		var site_url = "<?php echo domain_url(); ?>";
	</script>
    <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDQHu8c3CTgvmcdsG_5AvF0jYGWv7E_Mw0"></script>
    
    <script type="text/javascript" src="<?php echo jsPath(); ?>jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="<?php echo jsPath(); ?>bootstrap.min.js"></script>
    
</body>
</html>