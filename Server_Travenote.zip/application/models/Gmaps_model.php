<?php

class gmaps_model extends CI_Model{
    
    public function __construct() {
        parent::__construct();
    }
            
    function insertMarker($data){
        $input = array(
            'name'=>$data['name'],
            'lat'=>$data['lat'],
            'lng'=>$data['lng'],
            'address'=>$data['address'],
            'category'=>$data['category']
        );
        
        if(!$this->db->insert('markers',$input)){
            return FALSE;
        }
        else{
            return TRUE;
        }
    }
	
	function prosesLogin($input){
		$array = array(
				'email' => $input['username'],
				'password' => $input['password']
			);
		$this->db->where($array);
		$query = $this->db->get('user');
		$result = array("count"=>$query->num_rows(),
						"data"=>$query->row_array()
						);
		return $result;
	}
	
	function getAllLocationsByUser($userID){
		$this->db->where(array('id_user'=>$userID));
		return $this->db->get('markers')->result_array();
	}
	
	function getAvatar($id){
		$this->db->where(array('id_user'=>$id));
		return $this->db->get('avatar')->row_array();
	}
	
	function registerUser($data){
		$input = array(
			"nama"=>$data['name'],
			"email"=>$data['email'],
			"password"=>$data['password'],
			"alamat"=>$data['alamat'],
			"gender"=>$data['gender'],
			"save_picture"=> "NO"
		);
		
		if(!$this->db->insert('user',$input)){
            return FALSE;
        }
        else{
            return TRUE;
        }		
	}
    
    function getAllLocation(){
        $this->db->order_by('id_place', 'desc');
        $query = $this->db->get('markers');
		//$query = $this->db->query("SELECT * FROM markers ORDER BY id_place DESC");
        return($query->result_array());
		//return array("x"=>"test", "y"=>"tis");
    }
    
    function isPlaceExists($lat, $lng){
        /*Rumus Haversine
         * 3959 Untuk Jarak dalam Miles
         * 6371 Untuk Jarak dalam Kilometer 
         */
        
        $haversine = "6371 * acos( cos( radians($lat) ) * cos( radians(m.lat) ) * cos( radians($lng) - radians(m.lng) ) + sin( radians($lat) ) * sin( radians(m.lat) ) )";
        
        $str = "SELECT id_place, ".$haversine." AS distance FROM markers AS m HAVING distance < 1.5 ORDER BY distance";
        $query = $this->db->query($str);
        $msg = FALSE;
        if($query->num_rows() > 0){
            $msg = TRUE;
        }
        else{
            $msg = FALSE;
        }
        
        return array('message' => $msg,
            'data'=> $query->result_array());
    }
    
    function getDistance($latitude1, $longitude1, $latitude2, $longitude2) {  
        $earth_radius = 6371;  
        
        $dLat = deg2rad(doubleval($latitude2) - doubleval($latitude1));  
        $dLon = deg2rad(doubleval($longitude2) - doubleval($longitude1));  

        $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad(doubleval($latitude1))) * cos(deg2rad(doubleval($latitude2))) * sin($dLon/2) * sin($dLon/2);  
        $c = 2 * asin(sqrt($a));  
        $d = $earth_radius * $c;  

        return $d;  
    }
    
    function getNearestPlace($id){
        $query = $this->db->query('SELECT id_place, name FROM markers WHERE id_place = '.$id);
        return $query->result_array();
    }
	
	function getNearestPlaces($id){
        $query = $this->db->query('SELECT id_place, name FROM markers WHERE id_place = '.$id);
        return $query->row_array();
    }
    
    function getPlaceDetailDev($primary){
		$data['data_place'] = $this->db->query('SELECT * FROM markers WHERE id_place = '.$primary)->row_array();
        $data['report_place'] = $this->getPlaceComments($data['data_place']['id_place']);
        $data['img_data'] = $this->getPlaceImageData($data['data_place']['id_place']);
		return ($data);
    }
	
	function getPlaceImageData($id){
		$img = $this->db->query("SELECT title AS data_img FROM gambar WHERE id_place = ".$id." ORDER BY id_place")->result_array();
		return $img;
	}
	
	function getPlaceDetail($primary){
		$data['data_place'] = $this->db->query('SELECT * FROM markers WHERE lat = '.$primary)->row_array();
        $data['report_place'] = $this->db->query('SELECT * FROM komentar WHERE id_lokasi = '.$data['data_place']['id_place'].' ORDER BY id_komentar ASC')->result_array();
        return ($data);
    }
	
	function setLike($id, $like){
		//$this->db->update('postingan', array('like'=>"like + ".$like))
		//$this->db->where('id_postingan', $id);
		if($this->db->query("UPDATE postingan SET like_count = like_count + ".$like." WHERE id_postingan = ".$id)){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
    
    function getPlace($prymary){
        $query = $this->db->query("SELECT lat FROM markers WHERE id_place = $prymary");
        
        return ($query->row_array());
    }
	
	function addComment($input){
		$data = array(
			'id_place' => $input['id_place'],
			'author' => $input['author'],
			'comment' => $input['comment'],
			'email' => $input['email'],
			'date' => $input['date'],
			'time' => $input['time']
		);
		
		if(!$this->db->insert('comment', $data)){
			return FALSE;
		}else{
			return TRUE;;
		}
	}
	
	function getPlaceComments($id){
		$sql = "SELECT c.id_comment, u.nama AS author, c.comment, c.date, c.time, a.title FROM comment c JOIN user u ON c.id_user = u.id_user JOIN avatar a ON u.id_user = a.id_user WHERE c.id_place = ".$id." ORDER BY c.id_comment DESC";
		return $this->db->query($sql)->result_array();
	}
	
	function insertPlaceComment($data){
		if($this->db->insert('comment', $data)){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function insertPostActivity($data){
		if($this->db->insert('postingan', $data)){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function getUserActivity($id){
		$sql = "SELECT m.name AS judul_post, p.id_postingan, p.id_place, p.like_count, p.date, p.caption, u.nama, g.title AS img";
		$sql .= " FROM postingan p JOIN markers m ON p.id_place = m.id_place JOIN gambar g on g.id_place = p.id_place JOIN user u ON p.id_user = u.id_user";
		$sql .= " WHERE p.id_user = $id GROUP BY p.id_postingan ORDER BY p.id_postingan DESC";
		$activity = $this->db->query($sql)->result_array();
		
		for($i=0; $i<count($activity); $i++){
			$activity[$i]['qty_comment'] = ($this->countPostComment($activity[$i]['id_postingan']));
		}
		
		return $activity;
	}
	
	function countPostComment($id){
		return $this->db->query("SELECT id_comments FROM comments_post WHERE id_postingan = ".$id)->num_rows();
	}
	
	function getPostComments($id){
		$sql = "SELECT cp.isi, cp.date, cp.time, p.id_postingan, m.name, u.nama AS username, av.title AS avatar FROM comments_post cp JOIN postingan p ON p.id_postingan = cp.id_postingan JOIN markers m ON p.id_place = m.id_place JOIN user u ON u.id_user = cp.id_user JOIN avatar av ON av.id_user = u.id_user WHERE p.id_postingan = ".$id;
		return $this->db->query($sql)->result_array();
	}
	
	function insertPostComment($data){
		if($this->db->insert('comments_post', $data)){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function sharedDetail($id){
		return $this->db->get_where('markers', array('id_place'=>$id))->row_array();
	}
	
	function updateSetting($id, $data){
		$this->db->where('id_user', $id);
		
		if($this->db->update('user', $data)){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function getUser($id = NULL){
		if($id == NULL){
			$result = $this->db->get('user')->result_array();
		}
		else{
			$this->db->where('id_user', $id);
			$result = $this->db->get('user')->row_array();
		}
		
		return $result;
	}
	
	function saveGambar($data){
		if($this->db->insert("gambar", $data)){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function saveNewPlace($data){
		if($this->db->insert("markers", $data)){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function getMarkerTmpId($id){
		return $this->db->query("SELECT id_place FROM markers WHERE tmp_id = '".$id."'")->row_array();
	}
}
