<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class shared extends CI_Controller{
	
	function __construct(){
		parent::__construct();
	}
	
	function detail($id, $lat, $lng){
		$this->load->model("gmaps_model");
		$data['detail'] = $this->gmaps_model->sharedDetail($id);
		$this->load->view('shared_detail', $data);
	}
	
}