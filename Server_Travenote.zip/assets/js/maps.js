var map;
var result = {};
var markers = [];
var directionDisplay;
var directionService = new google.maps.DirectionsService();

    function initialize() {		
		directionDisplay = new google.maps.DirectionsRenderer();
		
      var mapOptions = {
        zoom: 15
      };
      map = new google.maps.Map(document.getElementById('map-canvas'),
          mapOptions);          
          
          //execute method that first running on load event          
          showMarkerPlace();
          getCurrentPos();
        
		directionDisplay.setMap(map);
    }
	
    function getCurrentPos(){
        // Try HTML5 geolocation
        if(navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) { 
            var pos = new google.maps.LatLng(parseFloat(position.coords.latitude),
                                             parseFloat(position.coords.longitude));

            new google.maps.InfoWindow({
              map: map,
              position: pos,
              content: 'Anda...'
            });

            map.setCenter(pos);
            
          }, function() {
            handleNoGeolocation(true);
          });
        } else {
          // Browser doesn't support Geolocation
          handleNoGeolocation(false);
        }
    }

    function showMarkerPlace(){
            $.ajax({
                url: site_url+'index.php/gmaps/getalllocation',
                dataType: 'json',
                success: function(data){
                    $.each(data, function(index, value){
                        var pos = new google.maps.LatLng(parseFloat(data[index].lat), parseFloat(data[index].lng));
                        placeMarker(pos);                            
                    });
                }
            });
      }

    function handleNoGeolocation(errorFlag) {
      if (errorFlag) {
        var content = 'Error: The Geolocation service failed.';
      } else {
        var content = 'Error: Your browser doesn\'t support geolocation.';
      }

      var options = {
        map: map,
        position: new google.maps.LatLng(60, 105),
        content: content
      };

      var infowindow = new google.maps.InfoWindow(options);
      map.setCenter(options.position);
    }

    function addPlace(){
        $("#loading_block").show();
        if(navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
              var pos = new google.maps.LatLng(position.coords.latitude,
                                               position.coords.longitude);

              var infowindow = new google.maps.InfoWindow({
                map: map,
                position: pos,
                content: 'Ini lokasi anda sekarang'
              });
              map.setCenter(pos);

            $.post('https://maps.googleapis.com/maps/api/geocode/json?latlng='+position.coords.latitude+','+position.coords.longitude+'&key=AIzaSyDQHu8c3CTgvmcdsG_5AvF0jYGWv7E_Mw0')
                .done(function(data){
					console.log(data);
                    var i;
                        if(parseInt(data.results[1].address_components[2].long_name) == null){
                            i = 1;
                        }else{
                            i = 0;
                        }                   
                    
                    var kec_long = data.results[i].address_components[2].long_name;
                    var kec_short = data.results[i].address_components[2].short_name;
                    var kab_long = data.results[i].address_components[3].long_name;
                    var kab_short = data.results[i].address_components[3].short_name;
                    $("#address").val(kec_short+" ("+kab_short+") "+i);
                });

              $("#addPlaceModal").modal('show');
              $("#addPlaceModal").on('shown.bs.modal', function(){
                $("#latitude").val(position.coords.latitude);
                $("#longitude").val(position.coords.longitude);
                $("#loading_block").hide();
              });

            }, function() {
              handleNoGeolocation(true);
            });
          } else {
            // Browser doesn't support Geolocation
            handleNoGeolocation(false);
            $("#loading_block").show();
          }
    }

    function placeMarker(pos) {
	var image_icon = [

    site_url+'assets/img/Biru.png',
    site_url+'assets/img/Hitam.png',
    site_url+'assets/img/Kuning.png'

  ];

	var icon = new google.maps.MarkerImage(
		image_icon[Math.floor(Math.random() * image_icon.length)],
		null,
		null,
		null,//new google.maps.Point(40, 110), 
		new google.maps.Size(30.77, 44.46)
	); 
	
        var marker = new google.maps.Marker({
            position: pos,
            map: map,
			icon: icon
        });
        
        google.maps.event.addListener(marker, 'click', function(){
            //$("#loading_block").show();
            $('#detail_place_modal').modal('show');						
			$("#loading_ajax_detail").show();
			$("#place_detail").empty();
            $.ajax({
                url: site_url+'index.php/gmaps/getplacedetail',
                data: {pry: marker.getPosition().lat()},
                type: 'POST',
				//dataType: 'json',
                success: function(){
					//setTimeout(function(){
					$("#loading_ajax_detail").hide();
				//}, 3500);
                },
				error: function(data){
					console.log(data);
				}
            }).done(function(data){
                //$("#loading_block").hide();
                $('#place_detail').html(data);								
            });
        });
        
        window.markers.push(marker);
    }

	function drawRoute(latDestination, lngDestination, TMode){
		if(navigator.geolocation){
			navigator.geolocation.getCurrentPosition(function(position) { 
				var start = new google.maps.LatLng(parseFloat(position.coords.latitude), parseFloat(position.coords.longitude));												 
				var destination = new google.maps.LatLng(parseFloat(latDestination), parseFloat(lngDestination));
        
				var draw_route = {
					origin: start,
					destination: destination,
					travelMode: google.maps.TravelMode[TMode]
				}
			
				directionService.route(draw_route, function(response, status) {
					if (status == google.maps.DirectionsStatus.OK) {
						directionDisplay.setDirections(response);
            //console.log(response );
					}
					else{
						//console.log(start);
						//console.log(destination);            
            alert("Mode yang anda pilih tidak di dukung di rute ini, kami memberikan rute dengan mode DRIVING");
            var draw_route_default = {
              origin: start,
              destination: destination,
              travelMode: google.maps.TravelMode.DRIVING
            }
            directionService.route(draw_route_default, function(response, status){
              directionDisplay.setDirections(response);
            });
					}
				});			
			
			}, function(){
				handleNoGeolocation(true);
			});
		}
		
		
		
	}

  function removeRoute(){
    directionDisplay.set('directions', null);
  }

    google.maps.event.addDomListener(window, 'load', function(){
        initialize();
    });