<?php
/*
 * Dalam kelas ini terdapat beberapa angka 0 dan 1 yg langsung mengisi sebuah variable
 * ini sebenarnya hanyalah boolean 1 = true 0 = false
 * hal itu bertujuan supaya saat data dikirim via JSON mudah untuk di parse lagi menjadi boolean :v 
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Gmaps extends CI_Controller {

	public function index()
	{
		$this->load->view('gmaps_view');
	}
	
	function __construct(){
		parent::__construct();
	}
	
	function isPlaceExists(){
		$data['lat'] = $this->input->post('latitude');
		$data['lng'] = $this->input->post('longitude');
		
		$this->load->model('gmaps_model');            
		$place = $this->gmaps_model->isPlaceExists($data['lat'], $data['lng']);
		
		if(!$place['message']){
			$msg['sts'] = 0;           
		}else{
			$msg['sts'] = 1;
			$msg['data'] = $this->gmaps_model->getNearestPlaces($place['data'][0]['id_place']);			
		}
		
		echo json_encode($msg);
	}
        
        function insertPlace(){
            $data['name'] = $this->input->post('name');
            $data['lat'] = $this->input->post('latitude');
            $data['lng'] = $this->input->post('longitude');
            $data['category'] = $this->input->post('category');
            $data['address'] = $this->input->post('address');
            $msg['status'] = 0;
            
            $this->load->model('gmaps_model');
            
            $place = $this->gmaps_model->isPlaceExists($data['lat'], $data['lng']);
            
            if(!$place['message']){
                if($this->gmaps_model->insertMarker($data)){
                    $msg['status'] = 1;
                }
                else{
                    $msg['status'] = 0;
                }                
            }else{
                $msg['status'] = 2;
                $msg['data'] = $place['data'];
            }
            echo json_encode($msg);
        }
        
        function getAllLocation(){
            $this->load->model('gmaps_model');
            //$result = json_encode($this->gmaps_model->getAllLocation());
            echo json_encode($this->gmaps_model->getAllLocation());
        }
        
        function cek($lat1, $lng1, $lat2, $lng2){
            $this->load->model('gmaps_model');
            print(($this->gmaps_model->getDistance($lat1, $lng1, $lat2, $lng2)));
        }
        
        function getNearestPlace(){
            $this->load->model('gmaps_model');
            $data = $this->gmaps_model->getNearestPlace($this->input->post('id'));
            echo json_encode($data);
        }
        
        function getPlaceDetail(/*pry*/){
            $this->load->model('gmaps_model'); 
			
            echo json_encode(($this->gmaps_model->getPlaceDetailDev($this->input->post('pry'))));
        }
		
		function getAllLocationsByUser(){
			$this->load->model('gmaps_model');            
            echo json_encode(($this->gmaps_model->getAllLocationsByUser($this->input->post('id_user'))));
		}
		
		function loginUser(){
			//$user = $this->input->post('email');
			//$pass = $this->input->post('password');
			$login = json_decode(file_get_contents("php://input"));
			$this->load->model('gmaps_model');
			$data = array(
					'username' => $login->email,
					'password' => $login->password
				);
			$a = $this->gmaps_model->prosesLogin($data);

			if($a['count']>0){				
				$this->session->set_userdata($a['data']);
				$a['avatar'] = $this->gmaps_model->getAvatar($a['data']['id_user']);
				$a['data']['avatar'] = $a['avatar']['title'];
				$a['data']['loged_in'] = 1;
				echo json_encode($a['data']);
			}
			else{
				echo json_encode(array("loged_in"=>0));
			}
		}
		
		function registerUser(){
			$input = array(
				"name"=>$data['name'],
				"email"=>$data['email'],
				"password"=>$data['password'],
				"alamat"=>$data['alamat'],
				"gender"=>$data['gender']
			);
			
			$this->load->model('gmaps_model');
			if($this->gmaps_model->registerUser($input)){
				$msg['status'] = 1;
			}
			else{
				$msg['status'] = 2;
			}
			echo json_encode($msg);
		}
		
		function addComment(){
			$data = array(
				'id_place' => $this->input->post('id_place'),
				'author' => 'Ervan',
				'comment' => $this->input->post('comment'),
				'email' => 'admin@travenote.com',
				'date' => $this->input->post('date'),
				'time' => $this->input->post('time')
			);			
			
			$this->load->model('gmaps_model');
			$this->gmaps_model->addComment($data);
		}
		
		function getLastComment(){
			$data['name'] = 'Ervan';//$this->input->post(name');
			$data['comment'] = $this->input->post('comment');
			$this->load->view('last_comment_view', $data);
		}
		
		function getPlaceComments(){			
			$id = $this->input->post('id');
			$this->load->model('gmaps_model');
			$output = $this->gmaps_model->getPlaceComments($id);
			echo json_encode($output);
		}
		
		function insertPlaceComment(){
			$comment = $this->input->post('txtComment');
			$id_place = $this->input->post('id_place');
			$id_user = $this->input->post('id_user');
			$tgl = $this->input->post('tgl');
			$wkt = $this->input->post('wkt');
			$author = $this->input->post('author');
			$input = array(			
				'id_place'=>$id_place,
				'id_user'=>$id_user,
				'author'=>$author,
				'comment'=>$comment,
				'date'=>$tgl,
				'time'=>$wkt
				
			);
			$this->load->model('gmaps_model');
			if($this->gmaps_model->insertPlaceComment($input)){
				$activity = array(			
					'id_place'=>$id_place,
					'id_user'=>$id_user,
					'caption'=>$comment,
					'date'=>$tgl,
					'time'=>$wkt					
				);
				$this->gmaps_model->insertPostActivity($activity);
				$stat = 1;
			}
			else{
				$stat = 0;
			}
			
			echo json_encode(array('stat'=>$stat));
		}
		
		function getUserActivity(){
			$id = $this->input->post('id_user');
			//echo json_encode(array('hhha'=>$id));
			$this->load->model('gmaps_model');
			$output = $this->gmaps_model->getUserActivity($id);
			echo json_encode($output);
		}
		
		function getAllPostComments(){
			$id = json_decode(file_get_contents("php://input"));
			$this->load->model('gmaps_model');
			$data = $this->gmaps_model->getPostComments($id->id);
			echo json_encode($data);
		}
		
		function insertPostComment(){
			$id = $this->input->post('id');
			$array = array(
				'id_postingan' => $this->input->post('id_postingan'),
				'id_user' => $this->input->post('id_user'),
				'isi' => $this->input->post('txtComment'),
				'date' => $this->input->post('tgl'),
				'time' => $this->input->post('wkt')
			);
			$this->load->model('gmaps_model');
			if($this->gmaps_model->insertPostComment($array)){
				$stat = 1;
			}
			else{
				$stat = 0;
			}
			echo json_encode(array('stat' => $stat));
		}
		
		function setLike(){
			//$id = $this->input->post('id');
			//$like = $this->input->post('like');
			$data = json_decode(file_get_contents("php://input"));
			$this->load->model('gmaps_model');
			
			if($this->gmaps_model->setlike($data->id, $data->like)){
				$stat = 1;
			}else{
				$stat = mysql_error();
			}
			
			echo json_encode(array('stat'=>$stat));
		}
		
		function updateSetting(){
			$setting = json_decode(file_get_contents("php://input"));
			$array = array(
				"nama"=> $setting->data->Nama,
				"email"=> $setting->data->Email,
				"password"=> $setting->data->Pass,
				"alamat"=> $setting->data->Alamat,
				"save_picture"=> $setting->data->Save
			);
			//echo json_encode($array);
			$this->load->model('gmaps_model');
			
			if($this->gmaps_model->updateSetting($setting->id, $array)){
				$stat = 1;
			}
			else{
				$stat = 0;
			}
			
			$x = $this->gmaps_model->getUser($setting->id);
			$avatar = $this->gmaps_model->getAvatar($setting->id);
			$user['nama'] = $x['nama'];
			$user['id_user'] = $x['id_user'];
			$user['email'] = $x['email'];
			$user['password'] = $x['password'];
			$user['alamat'] = $x['alamat'];
			$user['gender'] = $x['gender'];
			$user['save_picture'] = $x['save_picture'];
			$user['avatar'] = $avatar['title'];
			
			echo json_encode(array("stat"=>$stat, 'data'=>$user));
		}
		
		function saveNewPlace(){
			//$data = file_get_contents("php://input");
			echo json_encode(array("data"=>$_POST, "img"=>$_FILES));
		}
		
}
