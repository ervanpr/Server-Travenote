<?php 
/*
 * code by : amaros
 * mail    : xzanqu@gmail.com
 * date    : 28 jan 1011
 */
require_once (APPPATH.'controllers/base/web.base.class.php');
class Berita extends BaseApps {

    public function Berita() {
        parent::BaseApps();
        $this->load->model('jagoanmodel');
        $this->load->library('notification');
        $this->load->helper('jagoan_helper');
        stranger_berita();
    }
    
    function list_berita_page() {
        $this->load->library('pagination');
        $this->smarty->assign('main_page', 'web/berita/list_berita');
        $config['base_url'] = site_url("engine/berita/list_berita_page");
        $config['total_rows'] = $this->jagoanmodel->get_total_berita();
        $config['per_page'] = 9;
        $config['uri_segment'] = 4;
        $config['num_links'] = 5;
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Prev';
        $config['cur_tag_open'] = ' <a href="#" class="active">';
        $config['cur_tag_close'] = '</a>';
        $this->pagination->initialize($config);
        $pagging = $this->pagination->create_links();
        $this->smarty->assign("pagging", $pagging);
        $inipage=$this->uri->segment(4);
		$this->smarty->assign("inipage", $inipage);
        $data = $this->jagoanmodel->get_paginated_berita(intval($this->uri->segment(4, 0)), $config['per_page'], '1');
        $this->smarty->assign('data', $data);
        $this->smarty->assign('menu_title', "Berita");
        $this->tampil_notification();
        $this->smarty->view('common/document.html');
    }
    
    function add_berita() {
        $this->smarty->assign('main_page', 'web/berita/add_berita');
        $this->smarty->assign('menu_title', "Berita");
		$this->smarty->assign('tinymce', $this->tinymce->init());
        //$this->set_ckfinder();
        $this->smarty->view('common/document.html');
    }
    
    function delete_berita($id = '') {
        akses_berita($id);
        $this->smarty->assign('main_page', 'web/berita/delete_berita');
        $data = $this->jagoanmodel->get_berita_by_id($id);
        $this->smarty->assign('data', $data);
        $this->smarty->assign('menu_title', "Berita");
        $this->smarty->view('common/document.html');
    }
    
    function edit_berita($id = '') {
        akses_berita($id);
        $this->smarty->assign('main_page', 'web/berita/edit_berita');
        $this->smarty->assign('cke_path', BASEURL.'application/plugins/ckeditor');
        $data = $this->jagoanmodel->get_berita_by_id($id);
        $this->tampil_notification();
        $this->smarty->assign('data', $data);
        $this->smarty->assign('menu_title', "Berita");
        //$this->set_ckfinder();
        
        $this->smarty->assign('tinymce', $this->tinymce->init());
        $this->smarty->view('common/document.html');
    }

    
    //------------ function process here----------------
    
    function process_add_berita($jenis = '') {
        $this->load->library('notification');
        $this->notification->check_post('berita_jdl', 'Judul Berita', 'required');
        $this->notification->check_post('berita_detail', 'Content Berita', 'required');
        $this->notification->check_post('berita_aktif', 'Berita Aktif');
        $this->notification->check_post('berita_headline', 'Beria Headline');
        $this->notification->check_file('berita_img', 'Gambar');
        $aktif = 0;
        $headline = 0;
        if ($this->notification->valid_input()) {
            if ($this->input->post('berita_aktif') == '1') {
                $aktif = 1;
            }
            if ($this->input->post('berita_headline') == '1') {
                $headline = 0;
            }
            $img = $this->process_upload('add');
            if ($img) {                
                $this->upload_ftp($img);
                $parimg = date('Y').'/'.date('m').'/'.$img;
            } else {
                $parimg = "";
            }
            
            $param = array(date("Y-m-d H:i:s"), $this->input->post('berita_jdl'), $this->input->post('berita_detail'), $parimg, $jenis, $aktif, $headline, $this->uname, $this->set_permalink($this->input->post('berita_jdl')));
            
            if ($this->jagoanmodel->process_insert_berita($param)) {
            	$news = $this->jagoanmodel->get_last_berita();
				$this->create_pdf($news['berita_id']);
                $this->notification->clear_post();
                $this->notification->set_message("Berita berhasil disimpan");
                $this->notification->sent_notification(true);
				
				$this->load->library('xmlrpc');		
			
				$this->xmlrpc->server('http://www.amikomsocial.com/service/');
				$this->xmlrpc->method('postmsg');
					
				$request = array('150001',$this->input->post('berita_jdl'),'Web Service','STMIK AMIKOM Yogyakarta');
				$this->xmlrpc->set_debug(false);
				
				$this->xmlrpc->request($request);
				$this->xmlrpc->send_request();
				
                switch ($jenis) {
                    case 1:
                        redirect('engine/berita/list_berita_page');
                        break;
                    case 2:
                        redirect('engine/berita_it/list_berita_page');
                        break;
                    case 4:
                        redirect('engine/berita_e/list_berita_page');
                        break;
                    default:
                        redirect('engine/berita/list_berita_page');
                        break;
                }
            } else {
                $this->notification->set_message("Berita gagal disimpan");
                $this->notification->sent_notification(false);
                switch ($jenis) {
                    case 1:
                        redirect('engine/berita/add_berita');
                        break;
                    case 2:
                        redirect('engine/berita_it/add_berita');
                        break;
                    case 4:
                        redirect('engine/berita_e/add_berita');
                        break;
                    default:
                        redirect('engine/berita/add_berita');
                        break;
                }
            }
        } else {
            $this->notification->sent_notification(false);
            switch ($jenis) {
                case 1:
                    redirect('engine/berita/add_berita');
                    break;
                case 2:
                    redirect('engine/berita_it/add_berita');
                    break;
                case 4:
                    redirect('engine/berita_e/add_berita');
                    break;
                default:
                    redirect('engine/berita/add_berita');
                    break;
            }
        }
    }
    
    function process_update_berita($jenis = '') {
        $this->load->library('notification');
        $this->notification->check_post('berita_jdl', 'Judul Berita', 'required');
        $this->notification->check_post('berita_detail', 'Content Berita', 'required');
        //$this->notification->check_post('berita_jdl_en', 'Title');
        //$this->notification->check_post('berita_detail_en', 'Content');
        $this->notification->check_post('berita_aktif', 'Berita Aktif');
        $this->notification->check_post('berita_headline', 'Beria Headline');
        $this->notification->check_post('berita_id', 'id', 'required');
        $this->notification->check_file('berita_img', 'Gambar');
		$this->notification->check_post('tgl_edit','Tanggal');
        $aktif = 0;
        $headline = 0;
        if (! empty($_FILES['berita_img']['tmp_name'])) {
        	$img = $this->process_upload($this->input->post('berita_id'));
            if ($img) {
                //$data = $this->jagoanmodel->get_berita_by_id($this->input->post('berita_id'));                                
                $this->upload_ftp($img);
                $parimg = date('Y').'/'.date('m').'/'.$img;
                
                /*$parimg = $data['berita_img'];
                 $dir = substr($parimg, 0, 8);
                 $ext = $this->get_extension($parimg);
                 $par = str_replace( $ext, '', $parimg);
                 $par = str_replace($dir, '', $par);
                 
                 $img = $this->process_upload($par);
                 $this->upload_ftp($img);*/

            } else {
                $parimg = "";
            }
        } else {
            $data = $this->jagoanmodel->get_berita_by_id($this->input->post('berita_id'));
            $parimg = $data['berita_img'];
        }
        if ($this->notification->valid_input()) {
            if ($this->input->post('berita_aktif') == '1') {
                $aktif = 1;
            }
            if ($this->input->post('berita_headline') == '1') {
                $headline = 0;
            }
            
			if(trim($this->input->post('tgl_edit'))==''){
				$date_edit = date("Y-m-d H:i:s");
			}else{
				$date_edit = $this->input->post('tgl_edit');
			}
			
			
            $param = array(
			$date_edit, 
			$this->input->post('berita_jdl'), 
			$this->input->post('berita_detail'), 
			$jenis, 
			$aktif, 
			$headline, 
			//$this->input->post('berita_jdl_en'), 
			//$this->input->post('berita_detail_en'), 
			$this->set_permalink($this->input->post('berita_jdl')), 
			$parimg, 
			$this->input->post('berita_id'));
            
            if ($this->jagoanmodel->process_update_berita($param)) {
            	$this->create_pdf($this->input->post('berita_id'));
                $this->notification->clear_post();
                $this->notification->set_message("Berita berhasil disimpan");
                $this->notification->sent_notification(true);
                redirect('engine/berita/list_berita_page');
            } else {
                $this->notification->set_message("Berita gagal disimpan");
                $this->notification->sent_notification(false);
                redirect('engine/berita/edit_berita/'.$this->input->post('berita_id'));
            }
        } else {
            $this->notification->sent_notification(false);
            redirect('engine/berita/edit_berita/'.$this->input->post('berita_id'));
        }
    }
    
    function process_delete_berita() {
        $this->load->library('notification');
        $this->notification->check_post('berita_id', 'id', 'required');
        if ($this->notification->valid_input()) {
            if ($this->jagoanmodel->process_delete_berita($this->input->post('berita_id'))) {
                $this->notification->clear_post();
                $this->notification->set_message("Berita berhasil dihapus");
                $this->notification->sent_notification(true);
                redirect('engine/berita/list_berita_page');
            } else {
                $this->notification->set_message("Berita gagal dihapus");
                $this->notification->sent_notification(false);
                redirect('engine/berita/delete_berita/'.$this->input->post('berita_id'));
            }
        } else {
            $this->notification->sent_notification(false);
            redirect('engine/berita/delete_berita/'.$this->input->post('berita_id'));
        }
    }
    
	/**
	 * 09-04-2012 modify by fugu
	 * @action : supaya ketika klik headline, page tidak di redirect ke page paling awal pd paging yg ada dan mengatur maksimal 10 headline yg bs di set 
	 */
    function set_berita_headline($id = '',$page='') {    	
        if ($id != '') {
            $default_headline = 10;
            $jumlah_headline = $this->jagoanmodel->get_headline_berita_umum();			
			$tounheadline=0;
			if($jumlah_headline<$default_headline){$tounheadline=0;}			
			else{
				$tounheadline=$jumlah_headline - $default_headline;
				//if($tounheadline>=$default_headline){$tounheadline=0;}	
			}						
            $set_unheadline = $this->jagoanmodel->get_to_unheadline($tounheadline);            
            $berita = $this->jagoanmodel->get_berita_by_id($id);
            if ($berita['berita_img'] == '') {
                $this->notification->set_message("Berita headline lebih baik jika mempunyai gambar!");
                $this->notification->sent_notification(true);
            }
            
            if ($this->jagoanmodel->process_set_berita_headline($id)) {            					
                if (!empty($set_unheadline)) {
                    foreach ($set_unheadline as $res) {
                        $this->jagoanmodel->process_set_berita_nonheadline($res['berita_id']);
                    }
                }
                $this->jagoanmodel->process_set_berita_aktif($id);
                $this->notification->set_message("Berita berhasil diset Headline");
                $this->notification->sent_notification(true);
            }
        }
        redirect('engine/berita/list_berita_page/'.$page);
    }
    
	/**
	 * 09-04-2012 modify by fugu
	 * @action : supaya ketika klik unheadline, page tidak di redirect ke page paling awal pd paging yg ada 
	 */
    function set_berita_nonheadline($id = '',$page='') {
        if ($id != '') {
            if ($this->jagoanmodel->process_set_berita_nonheadline($id)) {
                $this->notification->set_message("Berita berhasil diset non headline");
                $this->notification->sent_notification(true);
            }
        }
        redirect('engine/berita/list_berita_page/'.$page);
    }
    
	/**
	 * 09-04-2012 modify by fugu
	 * @action : supaya ketika klik set berita aktif, page tidak di redirect ke page paling awal pd paging yg ada 
	 */
    function set_berita_aktif($id = '',$page='') {
        if ($id != '') {
            if ($this->jagoanmodel->process_set_berita_aktif($id)) {
                $this->notification->set_message("Berita berhasil diset Aktif");
                $this->notification->sent_notification(true);
            }
        }
        redirect('engine/berita/list_berita_page/'.$page);
    }
    
	/**
	 * 09-04-2012 modify by fugu
	 * @action : supaya ketika klik set berita non-aktif, page tidak di redirect ke page paling awal pd paging yg ada 
	 */
    function set_berita_nonaktif($id = '',$page='') {
        if ($id != '') {
            if ($this->jagoanmodel->process_set_berita_nonaktif($id)) {
                $this->jagoanmodel->process_set_berita_nonheadline($id);
                $this->notification->set_message("Berita berhasil diset non aktif");
                $this->notification->sent_notification(true);
            }
        }
        redirect('engine/berita/list_berita_page/'.$page);
    }
    
    //-------------utility function here------------------------
    function create_pdf($id = '') {
    	define('FPDF_FONTPATH', APPPATH.'plugins/font/');
        require (APPPATH.'plugins/fpdf.php');
		
		$data = $this->jagoanmodel->get_berita_by_id($id);
		$detail = strip_tags($data['berita_detail']);
        $ar = array('&nbsp;', 'n&quot');
        $detail = str_replace($ar, '', $detail);
        $detail = trim($detail);
		
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->setFont('arial', 'B', 10);
        //print($data['berita_img']);
        if ($data['berita_img'] != '') {
		    $pdf->Image('http://amikom.ac.id/images/berita/'.$data['berita_img'], 10, 8, 80);
            //$pdf->Image("../images/berita/$imageBerita", 10, 8, 80);
            $pdf->Cell(80);
            $pdf->Ln(60);
        }

        
        $pdf->setFont('arial', 'B', 14);
        $pdf->MultiCell(190, 5, $data['berita_jdl']);
        
        $pdf->setFont('arial', '', 8);
        $pdf->MultiCell(180, 5, $data['berita_tgl']);
        
        //$berita = removeHtmlString($isi_id);
        
        $pdf->setFont('arial', '', 10);
        $pdf->MultiCell(190, 5, $detail);
        
        //$pdf->SetY(-5);
        $pdf->setFont('Times', 'B', 8);
        $pdf->Cell(0, 10, 'www.amikom.ac.id', 0, 0, 'C');
        $pdf->Ln(40);
        
        $pdf->Output('../berita_pdf/'.$data['PERMALINK'].'.pdf', 'F');
        
    }

    function process_upload($param) {
        // load
        $this->load->library('notification');
        $this->load->library('uploader');
        if ($param == 'add') {
            $id_img = $this->jagoanmodel->get_insert_id_berita();
        } else {
            $id_img = $param;
        }
        if (! empty($_FILES['berita_img']['tmp_name'])) {
            // set file attachment
            $this->uploader->set_file($_FILES['berita_img']);
            // set rules (kosongkan jika tidak menggunakan batasan sama sekali)
            $rules = array('allowed_filesize'=>600000);
            $this->uploader->set_rules($rules);
            $this->uploader->set_file_name($id_img);
            // direktori
            //$dir = '/amikom2/public_html/public/images/berita/'.date('Y').'/'.date('m').'/';
            $dir = './bag/doc/images/';			
            // proses upload
            if ($this->uploader->upload_file_images($dir)) {            	
                return $this->uploader->get_file_name();
            } else {
                //echo $this->upload->message;               
                $this->notification->set_message($this->uploader->message);
                return false;
            }
        }
    }
    
    function upload_ftp($img) {
        $this->load->library('ftp');
        $file = $_FILES['berita_img']['tmp_name'];
        //$destination_file = '/public_html/public/images/berita/'.date('Y').'/'.date('m').'/'.$img;
        $dir='/public_html/images/berita/'.date('Y').'/'.date('m').'/'; 		       
        if ($this->ftp->connect()) {
        	if(is_dir($dir)){
        		//$this->ftp->mkdir($dir,0755);        	
			}			
        	$destination_file = $dir.$img;
            $move = $this->ftp->move('/public_html/jagoan2/bag/doc/images/'.$img, $destination_file);
        }
    }

    
    function set_permalink($judul) {
        $tmpstr = strip_tags(strtolower($judul));
        $tmpstr = str_replace(' ', '-', $tmpstr);
        $permalink = "";
        for ($i = 0; $i < strlen($tmpstr); $i++) {
            $char = substr($tmpstr, $i, 1);
            if ($char)
                if (preg_match("/^([-a-z0-9\-])+$/i", $char)) {
                    $permalink .= $char;
                }
        }
        if (strlen($permalink) > 50)
            $permalink = substr($permalink, 0, 50);
        $permalink = trim($permalink, '-');
        return $permalink;
    }
    
    function set_ckfinder() {
        // Setup CKEditor
        $this->load->library('ckeditor');
        $this->load->library('ckFinder');
        $this->ckeditor = new CKEditor();
        $this->ckeditor->basePath = base_url().'application/plugins/ckeditor/'; // konfigurasi path plugin
        $conf['toolbar'] = array(array('Source', '-', 'Bold', 'Italic', 'Underline', 'Strike', '-', 'NumberedList', 'BulletedList', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'Image', 'Link', 'Unlink', 'Table','-','PasteFromWord','PasteText'));
        $conf['skin'] = 'v2';
        $conf['width'] = '600';
        $this->ckeditor->returnOutput = true;
        //setup ckfinder in ckeditor
        CKFinder::SetupCKEditor($this->ckeditor, base_url().'application/plugins/ckfinder/'); // konfigurasi path plugin
        // set tek area id for ckeditor
        $textarea = array('berita_detail', 'berita_detail_en');
        $jv = '';
        foreach ($textarea as $value) {
            $jv = $jv.$this->ckeditor->replace($value, $conf);
        }
        $this->smarty->assign('jv', $jv);
    }
    
    function tampil_notification() {
        $this->load->library('notification');
        $arr_notify = $this->notification->get_notification();
        if (! empty($arr_notify['post'])) {
            $this->smarty->assign("data", $arr_notify['post']);
        }
        $this->smarty->assign("notification_msg", $arr_notify['message']);
        $this->smarty->assign("notification_status", ( empty($arr_notify['message_status']) ? 'red' : 'green'));
    }
    
    function stranger() {
        if (!$this->session->userdata('beritalevel') && !$this->session->userdata('superlevel')) {
            redirect('engine/main');
        }
    }
    
    function akses($id = '') {
        $data = $this->jagoanmodel->get_berita_by_id($id);
        if ($data['USERNAME'] != $this->uname && !$this->session->userdata('superlevel')) {
            $this->notification->set_message("Anda tidak punya akses untuk mengedit berita ini");
            $this->notification->sent_notification(false);
            redirect('engine/berita/list_berita_page/');
            exit();
        }
    }
    
    function get_extension($file_name) {
        $x = explode('.', $file_name);
        $x = end($x);
        return '.'.strtolower($x);
    }
    
    
}
?>
